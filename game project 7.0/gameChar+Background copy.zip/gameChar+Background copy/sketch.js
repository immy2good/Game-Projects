/*

The Game Project

2b - using variables

*/

var floorPos_y;

var gameChar_x;
var gameChar_y;

var treePos_x;
var treePos_y;

var canyonPos_x;
var canyonPos_y;
var collectable;

var mountain;
var cloud;


function setup()
{
    createCanvas(1024, 576);
    floorPos_y = 432; //NB. we are now using a variable for the floor position

    //NB. We are now using the built in variables height and width
    gameChar_x = width/2;
    gameChar_y = floorPos_y;

    treePos_x = width/2;
    treePos_y = height/2;

    canyonPos_x = gameChar_x// Initialize the 'canyon' object
}   canyonPos_y = 432// Initialize the 'c

function draw()
{
    background(100, 155, 255); //fill the sky blue

    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, height, width - floorPos_y); //draw some green ground

	//canyon
	fill(139,69,19);
	rect(0,canyonPos_y, 180,144);

	//water
	fill(30,144,255);
	rect(50,canyonPos_y,60,144);

	//draw mountains
    fill(205,133,63);
    triangle(340,canyonPos_y,260,180,180,canyonPos_y);
	triangle(400,canyonPos_y,320,220,250,canyonPos_y);

	//draw cloud 1
	fill(255,255,255);
    ellipse(200,150,80,80);
    ellipse(160,150,60,60);
    ellipse(240,150,60,60);
    //draw cloud 2
	fill(255,255,255);
    ellipse(150,150,80,80);
    ellipse(110,150,60,60);
    ellipse(190,150,60,60);
	//draw cloud 3
	fill(255,255,255);
    ellipse(400,50,90,90);
    ellipse(360,50,70,70);
    ellipse(440,50,70,70);

	 //5. a collectable token - eg. a jewel, fruit, coins
    //... add your code here
    //fill(192, 192, 192);
	//stroke(0);
    //ellipse(400,canyonPos_y - 10,20,20);
	//ellipse(400,canyonPos_y - 20,5,10);

	//inside collectable
	fill(0);
	ellipse(400,canyonPos_y - 10,15,5);
	ellipse(400,canyonPos_y - 10,5,15);

        //3. a tree
    fill(160,82,45);
    rect(treePos_x + 4,treePos_y + 144,60,-150);

    //Branches; add your code here
    fill(0,100,0);
    triangle(treePos_x - 75,treePos_y,treePos_x  + 43,100,650,treePos_y);
    //triangle(850,421,930,132,1010,421);
    triangle(treePos_x - 75,treePos_y + 40,treePos_x  + 43,100,650,treePos_y + 40);

	fill(192, 192, 192);
	stroke(0);
    ellipse(400,canyonPos_y - 10,20,20);
	ellipse(400,canyonPos_y - 20,5,10);

	//inside collectable
	fill(0);
	ellipse(400,canyonPos_y - 10,15,5);
	ellipse(400,canyonPos_y - 10,5,15);


    //Standing, facing frontwards
    fill(255, 128, 0);
    ellipse(gameChar_x, gameChar_y - 40, 20,20);

    //eyes
    fill(0);
    ellipse(gameChar_x - 5, gameChar_y - 42, 3,3);
    ellipse(gameChar_x + 5, gameChar_y - 42, 3,3);

    //mouth
    fill(255,255,255);
    rect(gameChar_x - 3, gameChar_y - 34,6,1);

    //nose
    fill(0);
    ellipse(gameChar_x, gameChar_y - 37.5, 2,3);


    //body, hands and legs

    fill(32, 32, 32);
    rect(gameChar_x -6, gameChar_y -30, 12,20);
    rect(gameChar_x - 6, gameChar_y -12, 4,10);
    rect(gameChar_x + 2, gameChar_y -12, 4,10);
    rect(gameChar_x - 11, gameChar_y - 30, 4,11);
    rect(gameChar_x + 7, gameChar_y - 30, 4,11);

    //feets
    fill(255, 128, 0);
    ellipse(gameChar_x -4, gameChar_y -2, 5,5);
    ellipse(gameChar_x +4, gameChar_y -2, 5,5);
    ellipse(gameChar_x +9, gameChar_y -18, 5,5);
    ellipse(gameChar_x -9, gameChar_y -18, 5,5);
}

function mousePressed()
{
gameChar_x = mouseX;
gameChar_y = mouseY;
}
